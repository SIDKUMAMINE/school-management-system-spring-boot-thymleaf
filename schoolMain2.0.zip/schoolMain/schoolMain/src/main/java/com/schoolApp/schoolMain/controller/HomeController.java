package com.schoolApp.schoolMain.controller;

import ch.qos.logback.core.model.Model;
import org.springframework.web.bind.annotation.GetMapping;

public class HomeController {

    @GetMapping("/login")
    public String login(){
        return "login";
    }
//
//
//    @GetMapping("/")
//    public String home(Model model) {
//        if (!userService.isAuthenticated()) {
//            return "redirect:/login";
//        } else {
//            model.addAttribute("message", "Welcome to the Home Page!");
//            return "home";
//        }
//    }

}
