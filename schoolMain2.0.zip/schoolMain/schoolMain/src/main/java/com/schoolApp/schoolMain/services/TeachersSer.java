package com.schoolApp.schoolMain.services;

import com.schoolApp.schoolMain.models.Teachers;
import com.schoolApp.schoolMain.repository.TeachersRepo;
import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeachersSer {
    @Autowired
    private TeachersRepo teacherRepo;

    public void addTeacher(Teachers teachers){
        teacherRepo.save(teachers);
    }

    public List<Teachers> getTeachers(){
        return teacherRepo.findAll();
    }
//
//    public void deleteByTeachersId(Long id) { // Correction du nom de la variable pour correspondre à l'argument
//        teacherRepo.deleteById(id); // Correction de l'utilisation de la variable 'id'
//    }

    public Teachers getTeacherById(long id) { // Correction de l'utilisation de 'id' au lieu de 'ID'
        Optional<Teachers> model = teacherRepo.findById(id); // Correction de l'utilisation de 'id'
        if (model.isPresent()) {
            return model.get();
        }
        return null;
    }

    public void updateTeacher(Teachers teacher) {

    }
}
