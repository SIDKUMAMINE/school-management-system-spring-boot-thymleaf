package com.schoolApp.schoolMain.services;

import com.schoolApp.schoolMain.models.Parents;
import com.schoolApp.schoolMain.repository.ParentsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class ParentsSer {

    @Autowired
    private ParentsRepo parentsRepo;


    public Collection<Parents> getlist(){

        return parentsRepo.findAll();
    }
    public Parents addParents(Parents parents){

        return parentsRepo.save(parents);
    }


    public List<Parents> getAllParents() {
        return parentsRepo.findAll();
    }
    public Parents getParentsById(Long id) {
        return parentsRepo.findById(id).orElse(null);
    }

    public void updateParents(Parents parents) {
    }

    public void deleteParentsById(Long id) {
    }
}
