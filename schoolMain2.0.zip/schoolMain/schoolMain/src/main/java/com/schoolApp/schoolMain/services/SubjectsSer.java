package com.schoolApp.schoolMain.services;


import com.schoolApp.schoolMain.models.Subjects;
import com.schoolApp.schoolMain.repository.SubjectsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubjectsSer {
    @Autowired
    private SubjectsRepo subjectsRepo;
    public Subjects addSubjects(Subjects subjects) {return subjectsRepo.save(subjects);
    }

    public List<Subjects> getAllSubjects(){
        return subjectsRepo.findAll();
    }


}
