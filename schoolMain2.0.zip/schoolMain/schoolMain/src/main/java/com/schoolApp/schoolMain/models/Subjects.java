package com.schoolApp.schoolMain.models;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Subjects {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ID;

    private String SubName;
    private String Chapters;

    @OneToMany(mappedBy = "subjects")
    private Set<Teachers> teachers = new HashSet<>();


}

