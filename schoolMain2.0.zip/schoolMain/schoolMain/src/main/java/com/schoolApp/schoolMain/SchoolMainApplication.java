package com.schoolApp.schoolMain;

import com.schoolApp.schoolMain.models.Student;
import com.schoolApp.schoolMain.models.Subjects;
import com.schoolApp.schoolMain.models.Teachers;
import com.schoolApp.schoolMain.services.StudentSer;
import com.schoolApp.schoolMain.services.SubjectsSer;
import com.schoolApp.schoolMain.services.TeachersSer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class SchoolMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolMainApplication.class, args);
	}



	@Bean
	public CommandLineRunner init(StudentSer studentService, SubjectsSer subjectsSer, TeachersSer teachersSer) {
		return args -> {
			studentService.addStudent(new Student(null, "Alice Johnson", 20, "A", "123 Main St, Springfield", "alice.johnson@example.com"));
			studentService.addStudent(new Student(null, "Bob Smith", 22, "B", "456 Elm St, Springfield", "bob.smith@example.com"));
			studentService.addStudent(new Student(null, "Charlie Brown", 21, "A", "789 Oak St, Springfield", "charlie.brown@example.com"));
			studentService.addStudent(new Student(null, "David Wilson", 23, "C", "101 Pine St, Springfield", "david.wilson@example.com"));
			studentService.addStudent(new Student(null, "Eve Davis", 19, "B", "202 Maple St, Springfield", "eve.davis@example.com"));
			teachersSer.addTeacher(new Teachers(null,"test",30,"adress","email@email", subjectsSer.addSubjects(new Subjects(null,"Test","test",null))));

		};
	}




}
