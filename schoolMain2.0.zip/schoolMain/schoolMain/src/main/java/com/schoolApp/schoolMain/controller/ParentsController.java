package com.schoolApp.schoolMain.controller;

import com.schoolApp.schoolMain.models.Parents;
import com.schoolApp.schoolMain.services.ParentsSer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ParentsController {

    @Autowired
    private ParentsSer parentsSer;

    @GetMapping("/parents")
    public String viewParentsList(Model model) {
        List<Parents> parentsList = parentsSer.getAllParents();
        model.addAttribute("parentsList", parentsList);
        return "parentsList";
    }

    @GetMapping("/parents/add")
    public String addParentsForm(Model model) {
        model.addAttribute("newParent", new Parents());
        return "addParent";
    }

    @PostMapping("/parents/add")
    public String addParents(@ModelAttribute Parents parents, Model model) {
        parentsSer.addParents(parents);
        model.addAttribute("message", "Parent added successfully");
        return "redirect:/parents";
    }

    @GetMapping("/parents/edit/{id}")
    public String editParentsForm(@PathVariable("id") Long id, Model model) {
        Parents parents = parentsSer.getParentsById(id);
        model.addAttribute("parent", parents);
        return "editParent";
    }

    @PostMapping("/parents/edit")
    public String updateParents(@ModelAttribute Parents parents, Model model) {
        parentsSer.updateParents(parents);
        model.addAttribute("message", "Parent updated successfully");
        return "redirect:/parents";
    }

    @GetMapping("/parents/delete/{id}")
    public String deleteParents(@PathVariable("id") Long id, Model model) {
        parentsSer.deleteParentsById(id);
        model.addAttribute("message", "Parent deleted successfully");
        return "redirect:/parents";
    }
}