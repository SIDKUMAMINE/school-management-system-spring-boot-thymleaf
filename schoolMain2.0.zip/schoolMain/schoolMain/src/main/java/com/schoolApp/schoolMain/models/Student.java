package com.schoolApp.schoolMain.models;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ID;

    private String Nom;
    private int Age;
    private String Grade;

    private String Address;

    private String email;
    @OneToOne
    private Parents parents;

    @ManyToOne
    private Subjects subjects;
    public Student(Long id, String name, int age, String grade, String address, String email) {
        this.ID = id;
        this.Nom = name;
        this.Age = age;
        this.Grade = grade;
        this.Address = address;
        this.email = email;
    }


}
