package com.schoolApp.schoolMain.services;

import com.schoolApp.schoolMain.dto.User;
import com.schoolApp.schoolMain.dto.UserDto;
import jakarta.validation.Valid;
import java.util.List;

public interface UserService {

    void saveUser(UserDto userDto);

    User findUserByEmail(String email);

    List<UserDto> findAllUsers();
}
