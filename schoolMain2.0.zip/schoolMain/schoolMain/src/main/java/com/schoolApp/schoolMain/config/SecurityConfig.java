/*package com.schoolApp.schoolMain.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())  // Disable CSRF protection
                .authorizeHttpRequests(requests -> {
                    requests
                            // Student-related endpoints
                            .requestMatchers("/addStudent", "/Student", "/Studentshow", "/Studentshow/edit/*")
                            .hasRole("ADMIN")

                            .requestMatchers("/register/**").permitAll()
                            .requestMatchers("/index").permitAll()
                            .requestMatchers("/users").hasRole("ADMIN")
                            // Teacher-related endpoints
                            .requestMatchers("/TeachersShow/edit/*",  "/TeachersShow/Edit/UpdateTeacher/*")
                            .hasRole("ADMIN")

                            // Subject-related endpoints
                            .requestMatchers("/AssignSub", "/addSubject", "/Subjects")
                            .permitAll()

                            // Public endpoints
                            .requestMatchers( "/", "/TeachersShow", "/addTeacher", "/webjars/**")
                            .permitAll()

                            // H2 Console access
                            .requestMatchers("/h2-console/**")
                            .permitAll();
                })
                .formLogin(Customizer.withDefaults())
                .formLogin(f-> f.defaultSuccessUrl("/"))// Default form login configuration
                .httpBasic(Customizer.withDefaults());  // Default HTTP Basic authentication configuration

        // To allow frames for H2 console
        http.headers(headers -> headers.frameOptions().sameOrigin());

        return http.build();
    }

    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails adminManager = User.withUsername("adminmanager")
                .password(passwordEncoder().encode("12345"))
                .roles("ADMIN")
                .build();
        UserDetails admin = User.withUsername("admin")
                .password(passwordEncoder().encode("12345"))
                .roles("ADMIN")
                .build();
        UserDetails user = User.withUsername("user")
                .password(passwordEncoder().encode("12345"))
                .roles("USER")
                .build();
        return new InMemoryUserDetailsManager(adminManager, admin, user);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}*/
