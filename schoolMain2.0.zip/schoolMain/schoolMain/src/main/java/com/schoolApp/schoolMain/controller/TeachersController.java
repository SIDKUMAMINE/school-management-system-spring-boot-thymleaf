package com.schoolApp.schoolMain.controller;

import com.schoolApp.schoolMain.models.Parents;
import com.schoolApp.schoolMain.models.Student;
import com.schoolApp.schoolMain.models.Subjects;
import com.schoolApp.schoolMain.models.Teachers;
import com.schoolApp.schoolMain.services.SubjectsSer;
import com.schoolApp.schoolMain.services.TeachersSer;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class TeachersController {
    @Autowired
    private TeachersSer teachersService;

    @Autowired
    private SubjectsSer subjectsService;

    @PostMapping("addTeacher")
    public String addTeacher(@ModelAttribute Teachers teacher, Model model){
        teachersService.addTeacher(teacher);
        return "redirect:/TeachersShow";
    }

    @GetMapping("addTeacher")
    public String showTeachers(Model model){

        model.addAttribute("newTeacher", new Teachers());
        model.addAttribute("subjects", subjectsService.getAllSubjects());
        return "TeachersAdd";
    }

    @GetMapping("TeachersShow")
    public String showAllTeachers(Model model){
        List<Teachers> teachers = teachersService.getTeachers();
        model.addAttribute("teachers", teachers); // Utilisez le camelCase pour les noms de variables
        System.out.println(teachers);
        return "TeachersShow";
    }

    @GetMapping("/TeachersShow/Edit/{id}")
    public String editTeacher(@PathVariable("id") long id, Model model){
        Teachers teachers = teachersService.getTeacherById(id);
        model.addAttribute("teachers", teachers);
        return "TeacherEdit";
    }

    @PostMapping("TeachersShow/Edit/UpdateTeacher")
    public String updateTeacher(@ModelAttribute Teachers teacher, Model model, HttpSession session){
        teachersService.updateTeacher(teacher); // Assurez-vous que la méthode existe dans votre service
        model.addAttribute("newParent", new Parents());
        model.addAttribute("newStudent", new Student());
        session.setAttribute("msg", "Teacher Updated Successfully...");
        return "StudentAdd"; // Vérifiez que cette vue existe et fait sens dans ce contexte
    }
}
